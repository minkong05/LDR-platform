# Evidence Bundle — 203.0.113.55

**Generated:** 2026-06-08 07:17:37 UTC

**Time range:** from 2026-01-01 00:00 UTC

**Source IP:** `203.0.113.55`


## Risk Assessment

**Risk score:** 60/100 (HIGH)

**Contributing alerts:** 3 open or triaged


| Severity | Count |

|----------|-------|

| High | 3 |


## Alerts

3 alert(s) recorded.


| Rule ID | Rule Name | Severity | Status | Events | Detected |

|---------|-----------|----------|--------|--------|----------|

| LDR-WEB-002 | Credential stuffing — high 401 rate from single IP | HIGH | OPEN | 20 | 2026-06-08 07:10:16 |

| LDR-WEB-006 | Account enumeration via repeated login failures | HIGH | OPEN | 15 | 2026-06-08 07:10:16 |

| LDR-WEB-001 | Brute force login failures from single IP | HIGH | OPEN | 10 | 2026-06-08 07:10:16 |


## Events

30 event(s) recorded.


**Top requested paths:**


| Path | Count |

|------|-------|

| `/login` | 30 |


## Analyst Notes

_Add investigation notes here._


## Files

| File | Contents |

|------|----------|

| `alerts.json` | Full alert records for this IP |

| `events.json` | Full event records for this IP |

| `summary.md` | This file |

